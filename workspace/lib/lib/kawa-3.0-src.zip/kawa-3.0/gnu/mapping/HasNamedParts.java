package gnu.mapping;

public interface HasNamedParts
{
  public Object get (String key);

  public boolean isConstant (String key);
}
