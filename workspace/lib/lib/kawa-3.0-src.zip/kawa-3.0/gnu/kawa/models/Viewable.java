package gnu.kawa.models;

public interface Viewable
{
  public void makeView (Display display, Object where);
}
