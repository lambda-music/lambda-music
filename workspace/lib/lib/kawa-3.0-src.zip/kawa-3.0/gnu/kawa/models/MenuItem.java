package gnu.kawa.models;

public class MenuItem extends Button
{
}
