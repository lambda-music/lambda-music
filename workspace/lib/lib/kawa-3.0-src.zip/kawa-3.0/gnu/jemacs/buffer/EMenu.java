package gnu.jemacs.buffer;

import gnu.lists.LList;

/**
 * @author Christian Surlykke
 *         10-07-2004
 */
public interface EMenu
{
  public void setMenu(LList menu);
}
