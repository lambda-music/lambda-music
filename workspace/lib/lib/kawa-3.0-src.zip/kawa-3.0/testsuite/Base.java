public interface Base {
    public String getTargetAxisName();
    public void setTargetAxisName(String v);
}
