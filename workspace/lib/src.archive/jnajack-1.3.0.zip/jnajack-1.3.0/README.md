JNAJack
=======

Java bindings to JACK Audio Connection Kit (http://jackaudio.org/)
